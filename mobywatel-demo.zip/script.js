document.getElementById('name').addEventListener('input', function() {
  document.getElementById('dispName').textContent = this.value;
});
document.getElementById('pesel').addEventListener('input', function() {
  document.getElementById('dispPesel').textContent = this.value;
});
document.getElementById('idno').addEventListener('input', function() {
  document.getElementById('dispIdno').textContent = this.value;
});
document.getElementById('dob').addEventListener('input', function() {
  var dateVal = this.value; 
  if (dateVal) {
    var parts = dateVal.split('-');
    document.getElementById('dispDob').textContent = parts.reverse().join('.');
  } else {
    document.getElementById('dispDob').textContent = '';
  }
});
document.getElementById('photo').addEventListener('change', function(event) {
  var file = event.target.files[0];
  if (file) {
    var reader = new FileReader();
    reader.onload = function(e) {
      var img = new Image();
      img.src = e.target.result;
      var preview = document.getElementById('photoPreview');
      preview.innerHTML = '';
      preview.appendChild(img);
    }
    reader.readAsDataURL(file);
  }
});